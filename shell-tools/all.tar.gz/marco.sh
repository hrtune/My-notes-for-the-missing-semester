# !/bin/bash
marco(){
pwd > /tmp/marco.txt
}

marco
